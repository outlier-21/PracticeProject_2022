const list = require('./utils')

// 在 Worker 线程执行上下文会全局暴露一个 worker 对象，直接调用 worker.onMeesage/postMessage 即可
worker.onMessage(function (res) {
  // console.log(res.location)
  var id=0;
  var  location=res.location
  for(var i = 0; i < list.length; i++)
{
    if(location.match(list[i].area))
    {
      id=list[i].id
      break;
    }
}
  worker.postMessage(id)

  worker.postMessage("OVER")
})









