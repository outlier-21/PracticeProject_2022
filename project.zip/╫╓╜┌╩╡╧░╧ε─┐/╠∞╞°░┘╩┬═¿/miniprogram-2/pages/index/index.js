// pages/index/index.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
      region:['北京市','北京市','东城区'],
      now:'',
      id:'101011600',
      worker:undefined
    },
    changeRegion:function(e){
      this.setData({
        region:e.detail.value
      })
      this.getWeater(); //更新天气
    },

    getWeater:function(){
      if(this.data.worker==undefined)
      this.data.worker = wx.createWorker('worker/request/workerId.js')

      var that=this;       
      this.data.worker.postMessage({
        location:that.data.region[2],
        key:'647bab7e451440af8e4d07ffc84125d0'
      })
      this.data.worker.onMessage(function(data)
      {
        if(data=="OVER")
         worker.terminate()
        // console.log("副线程传来的id是"+data)
        that.setData({id:data})
      })

      wx.request({
        url: 'https://devapi.qweather.com/v7/weather/now?',
        data:{
        //   location:'101010100',
          location:that.data.id,
          key:'647bab7e451440af8e4d07ffc84125d0'
        },
        success:function(res){
          console.log("这是查询结果")
          console.log(res.data.now)
          that.setData({now:res.data.now})
        }
      })
      console.log("这是this的值")
      console.log(that.now)
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      this.data.worker = wx.createWorker('worker/request/workerId.js')

        
      this.getWeater();
    },
  
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
      if(this.data.worker)
       this.data.worker.terminate()
    },
  
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
  
    },
  
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
  
    },
  
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
  
    }
  })